import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { useDispatch, useSelector } from 'react-redux'
import { ThumbsUp, ThumbsDown, Share2, BookmarkPlus, Bell, BellOff, MoreHorizontal } from 'lucide-react'
import { videoService, subscriptionService } from '@/services/api'
import { openAuthModal } from '@/store/slices/uiSlice'
import VideoPlayer from '@/components/player/VideoPlayer'
import CommentsSection from '@/components/comments/CommentsSection'
import VideoCard from '@/components/video/VideoCard'
import { formatCount, formatTimeAgo } from '@/utils/format'
import toast from 'react-hot-toast'

export default function WatchPage() {
  const { id } = useParams()
  const dispatch = useDispatch()
  const { isAuthenticated, user } = useSelector((s) => s.auth)
  const qc = useQueryClient()
  const [descExpanded, setDescExpanded] = useState(false)
  const [likeStatus, setLikeStatus] = useState(null)
  const [likeCounts, setLikeCounts] = useState({ likes: 0, dislikes: 0 })

  const { data: video, isLoading, error } = useQuery(
    ['video', id],
    () => videoService.getById(id).then((r) => {
      setLikeStatus(r.data.user_like_status)
      setLikeCounts({ likes: r.data.likes_count, dislikes: r.data.dislikes_count })
      return r.data
    }),
    { enabled: !!id }
  )

  const { data: related = [] } = useQuery(
    'videos-related',
    () => videoService.getAll().then((r) => (r.data.results || r.data).filter((v) => v.id !== id).slice(0, 20)),
    { staleTime: 120000 }
  )

  const likeMutation = useMutation(
    (action) => videoService.like(id, action),
    {
      onSuccess: (res) => {
        setLikeStatus(res.data.action)
        setLikeCounts({ likes: res.data.likes, dislikes: res.data.dislikes })
      },
    }
  )

  const subscribeMutation = useMutation(
    (subscribed) =>
      subscribed
        ? subscriptionService.unsubscribe(video?.uploader?.username)
        : subscriptionService.subscribe(video?.uploader?.username),
    {
      onSuccess: (_, subscribed) => {
        toast.success(subscribed ? 'Unsubscribed' : 'Subscribed!')
        qc.invalidateQueries(['video', id])
      },
    }
  )

  const handleLike = (action) => {
    if (!isAuthenticated) { dispatch(openAuthModal('login')); return }
    likeMutation.mutate(action)
  }

  const handleSubscribe = () => {
    if (!isAuthenticated) { dispatch(openAuthModal('login')); return }
    subscribeMutation.mutate(video?.uploader?.is_subscribed)
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href)
    toast.success('Link copied!')
  }

  if (isLoading) return <WatchSkeleton />
  if (error || !video) return (
    <div className="flex items-center justify-center py-32 text-vt-muted">
      <p>Video not found or unavailable.</p>
    </div>
  )

  const isOwner = isAuthenticated && user?.id === video.uploader?.id

  return (
    <div className="mx-auto max-w-[1800px] px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-7 xl:flex-row">
        {/* Main column */}
        <div className="flex-1 min-w-0">
          {/* Player */}
          <VideoPlayer video={video} />

          {/* Video info */}
          <div className="mt-5">
            <h1 className="text-2xl font-semibold leading-tight tracking-normal">{video.title}</h1>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              {/* Channel info */}
              <div className="flex items-center gap-3">
                <Link to={`/channel/${video.uploader?.username}`}>
                  <img src={video.uploader?.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover" />
                </Link>
                <div>
                  <Link to={`/channel/${video.uploader?.username}`} className="font-medium text-sm hover:text-blue-400 transition-colors">
                    {video.uploader?.display_name}
                    {video.uploader?.verified && <span className="ml-1 text-vt-muted text-xs">✓</span>}
                  </Link>
                  <p className="text-xs text-vt-muted">{formatCount(video.uploader?.subscribers_count)} subscribers</p>
                </div>
                <button
                  onClick={handleSubscribe}
                  className={`ml-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    video.uploader?.is_subscribed
                      ? 'bg-vt-chip text-vt-muted hover:bg-vt-chip-hover flex items-center gap-2'
                      : 'bg-vt-text text-vt-bg hover:bg-vt-accent hover:text-white'
                  }`}
                >
                  {video.uploader?.is_subscribed ? (
                    <><BellOff size={14} /> Subscribed</>
                  ) : 'Subscribe'}
                </button>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 flex-wrap">
                {/* Like / Dislike */}
                <div className="flex overflow-hidden rounded-full border border-vt-border/70 bg-vt-chip/80">
                  <button
                    onClick={() => handleLike('like')}
                    className={`flex items-center gap-2 px-4 py-2 text-sm hover:bg-vt-chip-hover transition-colors border-r border-vt-border ${
                      likeStatus === 'like' ? 'text-blue-400' : ''
                    }`}
                  >
                    <ThumbsUp size={16} fill={likeStatus === 'like' ? 'currentColor' : 'none'} />
                    {formatCount(likeCounts.likes)}
                  </button>
                  <button
                    onClick={() => handleLike('dislike')}
                    className={`flex items-center gap-2 px-4 py-2 text-sm hover:bg-vt-chip-hover transition-colors ${
                      likeStatus === 'dislike' ? 'text-red-400' : ''
                    }`}
                  >
                    <ThumbsDown size={16} fill={likeStatus === 'dislike' ? 'currentColor' : 'none'} />
                  </button>
                </div>

                <button onClick={handleShare} className="btn-secondary flex items-center gap-2">
                  <Share2 size={16} /> Share
                </button>

                <button
                  onClick={() => {
                    if (!isAuthenticated) { dispatch(openAuthModal('login')); return }
                    videoService.addWatchLater(id).then(() => toast.success('Saved to Watch later'))
                  }}
                  className="btn-secondary flex items-center gap-2"
                >
                  <BookmarkPlus size={16} /> Save
                </button>

                {isOwner && (
                  <Link to="/studio" className="btn-secondary flex items-center gap-2">
                    Edit
                  </Link>
                )}
              </div>
            </div>

            {/* Description */}
            <div className="premium-surface mt-5 p-5">
              <p className="text-sm text-vt-muted mb-1">
                {formatCount(video.views_count)} views · {formatTimeAgo(video.created_at)}
                {video.category && ` · ${video.category.name}`}
              </p>
              <div className={`text-sm whitespace-pre-wrap overflow-hidden transition-all ${descExpanded ? '' : 'line-clamp-3'}`}>
                {video.description || 'No description provided.'}
              </div>
              {video.description && video.description.length > 200 && (
                <button onClick={() => setDescExpanded(!descExpanded)} className="text-sm font-medium mt-2">
                  {descExpanded ? 'Show less' : 'Show more'}
                </button>
              )}
              {video.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {video.tags.map((t) => (
                    <span key={t.id} className="text-xs text-vt-accent">#{t.name}</span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Comments */}
          {video.allow_comments && (
            <CommentsSection videoId={id} commentsCount={video.comments_count} />
          )}
        </div>

        {/* Sidebar — related videos */}
        <aside className="flex-shrink-0 xl:w-[420px]">
          <div className="mb-4 hidden items-center justify-between xl:flex">
            <div>
              <p className="lux-eyebrow">Continue watching</p>
              <h2 className="mt-1 font-semibold">Up next</h2>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            {related.map((v) => (
              <VideoCard key={v.id} video={v} layout="list" />
            ))}
          </div>
        </aside>
      </div>
    </div>
  )
}

function WatchSkeleton() {
  return (
    <div className="max-w-[1800px] mx-auto px-4 py-6">
      <div className="flex gap-6 flex-col xl:flex-row">
        <div className="flex-1 min-w-0 space-y-4">
          <div className="aspect-video skeleton rounded-xl" />
          <div className="h-7 skeleton rounded w-3/4" />
          <div className="flex gap-3">
            <div className="w-10 h-10 skeleton rounded-full" />
            <div className="flex-1 space-y-2">
              <div className="h-4 skeleton rounded w-40" />
              <div className="h-3 skeleton rounded w-24" />
            </div>
          </div>
        </div>
        <aside className="xl:w-96 space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex gap-3">
              <div className="w-40 aspect-video skeleton rounded-xl flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="h-4 skeleton rounded" />
                <div className="h-3 skeleton rounded w-2/3" />
              </div>
            </div>
          ))}
        </aside>
      </div>
    </div>
  )
}
