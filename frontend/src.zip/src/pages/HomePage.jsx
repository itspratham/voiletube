import { useState } from 'react'
import { useQuery } from 'react-query'
import { useDispatch, useSelector } from 'react-redux'
import { videoService } from '@/services/api'
import { setActiveCategory } from '@/store/slices/uiSlice'
import VideoGrid from '@/components/video/VideoGrid'
import { Sparkles } from 'lucide-react'

const CATEGORIES = ['All', 'Music', 'Gaming', 'News', 'Sports', 'Technology',
    'Education', 'Comedy', 'Science', 'Travel', 'Food']

export default function HomePage() {
  const dispatch = useDispatch()
  const { activeCategory } = useSelector((s) => s.ui)

  const { data, isLoading } = useQuery(
    ['videos', activeCategory],
    () => videoService.getAll(activeCategory !== 'All' ? { category: activeCategory.toLowerCase() } : {})
      .then((r) => r.data.results || r.data),
    { staleTime: 60000 }
  )

  return (
    <div className="lux-page">
      <div className="lux-container">
        <div className="mb-7 grid gap-5 rounded-lg border border-vt-border/80 bg-vt-surface/60 px-5 py-6 shadow-[0_24px_70px_rgb(var(--vt-shadow)/0.08)] backdrop-blur-2xl md:grid-cols-[1fr_auto] md:items-end md:px-7">
          <div className="flex flex-col gap-2">
            <p className="lux-eyebrow">Voiletube Spectrum</p>
            <h1 className="lux-section-title max-w-3xl">Stream what the world is watching</h1>
            <p className="max-w-2xl text-sm leading-6 text-vt-muted">
              A refined feed for cinematic uploads, live creators, and culture-scale conversations.
            </p>
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-vt-border/80 bg-vt-bg/50 px-3 py-2 text-xs font-medium text-vt-muted shadow-inner md:flex">
            <Sparkles size={14} className="text-vt-gold" />
            Curated for scale
          </div>
        </div>
      {/* Category chips */}
        <div className="sticky top-[72px] z-30 -mx-4 mb-7 flex gap-2 overflow-x-auto border-y border-vt-border/70 bg-vt-bg/70 px-4 py-3 backdrop-blur-2xl scrollbar-none sm:top-[72px]">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => dispatch(setActiveCategory(cat))}
            className={cat === activeCategory ? 'chip-active' : 'chip'}
          >
            {cat}
          </button>
        ))}
        </div>

        <VideoGrid videos={data || []} loading={isLoading} emptyMessage="No videos yet. Upload the first feature." />
      </div>
    </div>
  )
}
