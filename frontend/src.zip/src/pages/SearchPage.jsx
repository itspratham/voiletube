import { useSearchParams } from 'react-router-dom'
import { useQuery } from 'react-query'
import { videoService } from '@/services/api'
import VideoCard from '@/components/video/VideoCard'
import { VideoGridSkeleton } from '@/components/video/VideoGrid'
import { Search, SlidersHorizontal } from 'lucide-react'
import { useState } from 'react'

const SORT_OPTIONS = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'recent', label: 'Upload date' },
  { value: 'views', label: 'View count' },
  { value: 'likes', label: 'Rating' },
]

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const q = searchParams.get('q') || ''
  const [sort, setSort] = useState('relevance')

  const { data, isLoading } = useQuery(
    ['search', q, sort],
    () => videoService.search({ q, sort }).then((r) => r.data),
    { enabled: !!q }
  )

  const videos = data?.results || []

  return (
    <div className="lux-page">
      <div className="mx-auto w-full max-w-6xl">
      {q && (
        <div className="premium-surface mb-6 flex flex-wrap items-center justify-between gap-4 px-5 py-4">
          <p className="text-sm text-vt-muted">
            {data?.count != null ? `About ${data.count} results for ` : 'Results for '}
            <span className="text-vt-text font-medium">"{q}"</span>
          </p>
          <div className="flex items-center gap-2">
            <SlidersHorizontal size={16} className="text-vt-muted" />
            <span className="text-sm text-vt-muted">Sort by:</span>
            <div className="flex gap-1">
              {SORT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setSort(opt.value)}
                  className={sort === opt.value ? 'chip-active text-xs' : 'chip text-xs'}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {!q ? (
        <div className="page-empty">
          <Search size={38} />
          <p>Search for videos, channels, and more</p>
        </div>
      ) : isLoading ? (
        <div className="space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="flex gap-4">
              <div className="w-64 aspect-video skeleton rounded-xl flex-shrink-0" />
              <div className="flex-1 space-y-2 py-2">
                <div className="h-5 skeleton rounded w-3/4" />
                <div className="h-3 skeleton rounded w-1/3" />
                <div className="h-3 skeleton rounded w-1/4" />
                <div className="h-4 skeleton rounded w-full mt-3" />
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="page-empty">
          <Search size={38} />
          <p>No results found for "{q}"</p>
        </div>
      ) : (
        <div className="space-y-4">
          {videos.map((video) => (
            <SearchResultCard key={video.id} video={video} />
          ))}
        </div>
      )}
      </div>
    </div>
  )
}

function SearchResultCard({ video }) {
  return (
    <div className="flex gap-4 group">
      <VideoCard video={video} layout="list" />
    </div>
  )
}
