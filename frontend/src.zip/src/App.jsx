import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { fetchCurrentUser } from '@/store/slices/authSlice'

import Layout from '@/components/layout/Layout'
import HomePage from '@/pages/HomePage'
import WatchPage from '@/pages/WatchPage'
import SearchPage from '@/pages/SearchPage'
import ChannelPage from '@/pages/ChannelPage'
import TrendingPage from '@/pages/TrendingPage'
import SubscriptionsPage from '@/pages/SubscriptionsPage'
import HistoryPage from '@/pages/HistoryPage'
import WatchLaterPage from '@/pages/WatchLaterPage'
import LikedVideosPage from '@/pages/LikedVideosPage'
import StudioPage from '@/pages/StudioPage'
import AuthModal from '@/components/auth/AuthModal'
import UploadModal from '@/components/video/UploadModal'
import { useTheme } from '@/components/theme/ThemeProvider'

export default function App() {
  const dispatch = useDispatch()
  const { resolvedTheme } = useTheme()
  const { initialized } = useSelector((s) => s.auth)
  const { authModalOpen, uploadModalOpen } = useSelector((s) => s.ui)

  useEffect(() => {
    if (localStorage.getItem('access_token')) {
      dispatch(fetchCurrentUser())
    } else {
      dispatch({ type: 'auth/fetchMe/rejected', payload: null })
    }
  }, [dispatch])

  if (!initialized) {
    return (
      <div
        data-theme={resolvedTheme}
        className="app-theme-root flex items-center justify-center min-h-screen bg-vt-bg text-vt-text"
      >
        <div className="w-10 h-10 border-2 border-vt-accent border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <BrowserRouter>
      <div
        data-theme={resolvedTheme}
        className="app-theme-root min-h-screen bg-vt-bg text-vt-text"
      >
        <AppRoutes />
        {authModalOpen && <AuthModal />}
        {uploadModalOpen && <UploadModal />}
      </div>
    </BrowserRouter>
  )
}

function AppRoutes() {
  const location = useLocation()

  return (
    <Layout>
      <Routes location={location}>
        <Route path="/" element={<HomePage key={location.pathname + location.search} />} />
        <Route path="/watch/:id" element={<WatchPage key={location.pathname + location.search} />} />
        <Route path="/search" element={<SearchPage key={location.pathname + location.search} />} />
        <Route path="/channel/:username" element={<ChannelPage key={location.pathname + location.search} />} />
        <Route path="/trending" element={<TrendingPage key={location.pathname + location.search} />} />
        <Route path="/subscriptions" element={<SubscriptionsPage key={location.pathname + location.search} />} />
        <Route path="/history" element={<HistoryPage key={location.pathname + location.search} />} />
        <Route path="/watch-later" element={<WatchLaterPage key={location.pathname + location.search} />} />
        <Route path="/liked" element={<LikedVideosPage key={location.pathname + location.search} />} />
        <Route path="/studio" element={<StudioPage key={location.pathname + location.search} />} />
      </Routes>
    </Layout>
  )
}
