import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { MoreVertical, Clock, BookmarkPlus, Plus } from 'lucide-react'
import { formatCount, formatTimeAgo, formatDuration } from '@/utils/format'
import { useDispatch, useSelector } from 'react-redux'
import { openAuthModal } from '@/store/slices/uiSlice'
import { videoService } from '@/services/api'
import toast from 'react-hot-toast'
import BrandMark from '@/components/brand/BrandMark'

export default function VideoCard({ video, layout = 'grid' }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [playlistOpen, setPlaylistOpen] = useState(false)
  const [playlists, setPlaylists] = useState([])
  const [newPlaylistTitle, setNewPlaylistTitle] = useState('')
  const [playlistLoading, setPlaylistLoading] = useState(false)
  const { isAuthenticated } = useSelector((s) => s.auth)
  const dispatch = useDispatch()

  const handleWatchLater = async (e) => {
    e.preventDefault()
    if (!isAuthenticated) { dispatch(openAuthModal('login')); return }
    try {
      await videoService.addWatchLater(video.id)
      toast.success('Saved to Watch later')
    } catch {
      toast.error('Could not save')
    }
    setMenuOpen(false)
  }

  const loadPlaylists = async () => {
    if (!isAuthenticated) { dispatch(openAuthModal('login')); return }
    setPlaylistOpen(true)
    setPlaylistLoading(true)
    try {
      const { data } = await videoService.myPlaylists()
      setPlaylists(data.results || data)
    } catch {
      toast.error('Could not load playlists')
    } finally {
      setPlaylistLoading(false)
    }
  }

  const saveToPlaylist = async (playlistId) => {
    try {
      await videoService.addToPlaylist(playlistId, video.id)
      toast.success('Saved to playlist')
      setMenuOpen(false)
      setPlaylistOpen(false)
    } catch {
      toast.error('Could not save to playlist')
    }
  }

  const createAndSavePlaylist = async (e) => {
    e.preventDefault()
    const title = newPlaylistTitle.trim()
    if (!title) return
    try {
      const { data: playlist } = await videoService.createPlaylist({ title, is_public: true })
      await saveToPlaylist(playlist.id)
      setNewPlaylistTitle('')
    } catch {
      toast.error('Could not create playlist')
    }
  }

  if (layout === 'list') {
    return (
      <Link to={`/watch/${video.id}`} className="group flex gap-3 rounded-lg p-1.5 transition-colors hover:bg-vt-chip/60">
        <ThumbnailBox video={video} className="w-40 flex-shrink-0 sm:w-64" compact />
        <div className="min-w-0 flex-1 py-1.5">
          <h3 className="line-clamp-2 text-sm font-medium leading-snug transition-colors group-hover:text-vt-accent">
            {video.title}
          </h3>
          <ChannelInfo video={video} />
        </div>
      </Link>
    )
  }

  return (
    <div className="group animate-fade-in rounded-lg p-1.5 transition-colors hover:bg-vt-surface/50">
      <Link to={`/watch/${video.id}`} className="block">
        <ThumbnailBox video={video} />
      </Link>
      <div className="mt-3 flex gap-3 px-0.5 pb-1">
        <Link to={`/channel/${video.uploader?.username}`} className="flex-shrink-0">
          <img
            src={video.uploader?.avatar_url}
            alt={video.uploader?.display_name}
            className="h-9 w-9 rounded-full object-cover ring-1 ring-vt-border/90"
          />
        </Link>
        <div className="flex-1 min-w-0">
          <Link to={`/watch/${video.id}`}>
            <h3 className="line-clamp-2 text-sm font-medium leading-snug transition-colors hover:text-vt-accent">
              {video.title}
            </h3>
          </Link>
          <ChannelInfo video={video} />
        </div>
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="btn-ghost h-8 w-8 rounded-full p-0 opacity-0 transition-opacity group-hover:opacity-100"
          >
            <MoreVertical size={16} />
          </button>
          {menuOpen && (
            <div className="glass-panel-strong absolute right-0 top-8 z-20 w-52 rounded-lg py-1 animate-fade-in">
              <button onClick={handleWatchLater} className="flex items-center gap-3 w-full px-4 py-2.5 text-sm hover:bg-vt-chip transition-colors">
                <Clock size={16} /> Add to Watch later
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault()
                  loadPlaylists()
                }}
                className="flex items-center gap-3 w-full px-4 py-2.5 text-sm hover:bg-vt-chip transition-colors"
              >
                <BookmarkPlus size={16} /> Save to playlist
              </button>
              {playlistOpen && (
                <div className="border-t border-vt-border p-2">
                  {playlistLoading ? (
                    <p className="px-2 py-2 text-xs text-vt-muted">Loading playlists...</p>
                  ) : playlists.length > 0 ? (
                    <div className="max-h-36 overflow-y-auto">
                      {playlists.map((playlist) => (
                        <button
                      key={playlist.id}
                          onClick={(e) => {
                            e.preventDefault()
                            saveToPlaylist(playlist.id)
                          }}
                          className="w-full rounded-md px-2 py-1.5 text-left text-xs hover:bg-vt-chip"
                        >
                          {playlist.title}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="px-2 py-2 text-xs text-vt-muted">No playlists yet</p>
                  )}
                  <form onSubmit={createAndSavePlaylist} className="mt-2 flex gap-1">
                    <input
                      value={newPlaylistTitle}
                      onChange={(e) => setNewPlaylistTitle(e.target.value)}
                      onClick={(e) => e.preventDefault()}
                      placeholder="New playlist"
                      className="min-w-0 flex-1 rounded-md border border-vt-border bg-vt-surface/80 px-2 py-1 text-xs outline-none focus:border-vt-accent"
                    />
                    <button className="btn-ghost rounded-md p-1" title="Create playlist">
                      <Plus size={14} />
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function ThumbnailBox({ video, className = '', compact = false }) {
  const [loaded, setLoaded] = useState(false)
  const [generatedThumbnail, setGeneratedThumbnail] = useState(null)

  useEffect(() => {
    setLoaded(false)
  }, [video.id, video.thumbnail_url])

  useEffect(() => {
    if (video.thumbnail_url) {
      setGeneratedThumbnail(null)
      return undefined
    }

    const sourceUrl = video.url_720p || video.url_480p || video.url_360p || video.video_file
    if (!sourceUrl || typeof document === 'undefined') {
      setLoaded(true)
      return undefined
    }

    let cancelled = false
    const previewVideo = document.createElement('video')
    const canvas = document.createElement('canvas')

    previewVideo.preload = 'metadata'
    previewVideo.muted = true
    previewVideo.playsInline = true
    previewVideo.crossOrigin = 'anonymous'
    previewVideo.src = sourceUrl

    const cleanup = () => {
      previewVideo.pause()
      previewVideo.removeAttribute('src')
      previewVideo.load()
    }

    const captureFrame = () => {
      if (cancelled || !previewVideo.videoWidth || !previewVideo.videoHeight) return

      canvas.width = previewVideo.videoWidth
      canvas.height = previewVideo.videoHeight

      try {
        canvas.getContext('2d')?.drawImage(previewVideo, 0, 0, canvas.width, canvas.height)
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82)
        if (!cancelled) {
          setGeneratedThumbnail(dataUrl)
          setLoaded(true)
        }
      } catch {
        if (!cancelled) setLoaded(true)
      } finally {
        cleanup()
      }
    }

    const handleLoadedMetadata = () => {
      const captureAt = Math.min(1, Math.max(previewVideo.duration / 3, 0))
      if (captureAt > 0) {
        previewVideo.currentTime = captureAt
      } else {
        captureFrame()
      }
    }

    const handleSeeked = () => captureFrame()
    const handleError = () => {
      if (!cancelled) setLoaded(true)
      cleanup()
    }

    previewVideo.addEventListener('loadedmetadata', handleLoadedMetadata)
    previewVideo.addEventListener('seeked', handleSeeked, { once: true })
    previewVideo.addEventListener('error', handleError)

    return () => {
      cancelled = true
      previewVideo.removeEventListener('loadedmetadata', handleLoadedMetadata)
      previewVideo.removeEventListener('seeked', handleSeeked)
      previewVideo.removeEventListener('error', handleError)
      cleanup()
    }
  }, [video.thumbnail_url, video.url_720p, video.url_480p, video.url_360p, video.video_file])

  const thumbnailSrc = video.thumbnail_url || generatedThumbnail

  return (
    <div className={`relative aspect-video overflow-hidden rounded-lg bg-vt-surface shadow-[0_18px_50px_rgb(var(--vt-shadow)/0.13)] ring-1 ring-vt-border/80 ${className}`}>
      {!loaded && <div className="absolute inset-0 skeleton" />}
      {thumbnailSrc ? (
        <img
          src={thumbnailSrc}
          alt={video.title}
          className={`h-full w-full object-cover transition duration-500 group-hover:scale-[1.025] ${loaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setLoaded(true)}
          onError={() => setLoaded(true)}
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-vt-chip">
          <BrandMark className="h-12 w-12 opacity-60" />
        </div>
      )}
      {video.duration_formatted && (
        <span className={`absolute bottom-2 right-2 rounded-full bg-black/75 px-2 py-0.5 text-xs font-medium text-white backdrop-blur ${compact ? 'text-[11px]' : ''}`}>
          {video.duration_formatted}
        </span>
      )}
      {video.status === 'processing' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/55 backdrop-blur-sm">
          <span className="rounded-full bg-black/80 px-3 py-1 text-xs text-white">Processing...</span>
        </div>
      )}
    </div>
  )
}

function ChannelInfo({ video }) {
  return (
    <>
      <Link
        to={`/channel/${video.uploader?.username}`}
        className="mt-1 block text-xs text-vt-muted transition-colors hover:text-vt-text"
      >
        {video.uploader?.display_name}
        {video.uploader?.verified && (
          <span className="ml-1 text-vt-muted" title="Verified">✓</span>
        )}
      </Link>
      <p className="text-xs text-vt-muted">
        {formatCount(video.views_count)} views - {formatTimeAgo(video.created_at)}
      </p>
    </>
  )
}
