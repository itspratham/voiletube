import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { notificationService } from '@/services/api'
import { formatTimeAgo } from '@/utils/format'
import { Bell } from 'lucide-react'

function resolveNotificationPath(notification) {
  if (!notification?.link) return null

  let rawPath = notification.link

  try {
    const url = new URL(notification.link, window.location.origin)
    rawPath = `${url.pathname}${url.search}${url.hash}`
  } catch {
    rawPath = notification.link
  }

  if (rawPath.startsWith('/watch/')
    || rawPath.startsWith('/channel/')
    || rawPath.startsWith('/search')
    || rawPath.startsWith('/subscriptions')
    || rawPath.startsWith('/history')
    || rawPath.startsWith('/watch-later')
    || rawPath.startsWith('/studio')
    || rawPath.startsWith('/trending')) {
    return rawPath
  }

  const videoMatch = rawPath.match(/\/videos\/([0-9a-f-]+)\/?$/i)
  if (videoMatch) {
    return `/watch/${videoMatch[1]}`
  }

  const channelMatch = rawPath.match(/\/(?:auth|users|channels)\/([^/?#]+)\/?$/i)
  if (channelMatch) {
    return `/channel/${channelMatch[1]}`
  }

  if (rawPath.startsWith('/api/')) {
    return rawPath.replace(/^\/api/, '')
  }

  return rawPath.startsWith('/') ? rawPath : `/${rawPath}`
}

export default function NotificationPanel({ onClose }) {
  const ref = useRef(null)
  const hasMarkedReadRef = useRef(false)
  const qc = useQueryClient()
  const navigate = useNavigate()

  const { data: notifications = [] } = useQuery(
    'notifications',
    () => notificationService.getAll().then((r) => r.data)
  )

  const markRead = useMutation(
    () => notificationService.markAllRead(),
    { onSuccess: () => qc.invalidateQueries('notifications') }
  )

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose()
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  useEffect(() => {
    const hasUnreadNotifications = notifications.some((notification) => !notification.is_read)
    if (!hasUnreadNotifications || hasMarkedReadRef.current || markRead.isLoading) {
      return
    }

    hasMarkedReadRef.current = true
    markRead.mutate()
  }, [notifications, markRead])

  const handleNotificationClick = (notification) => {
    const targetPath = resolveNotificationPath(notification)

    if (!targetPath) {
      onClose()
      return
    }

    navigate(targetPath)
    onClose()
  }

  return (
    <div
      ref={ref}
      className="absolute right-0 top-10 z-50 w-80 overflow-hidden rounded-xl border border-vt-border bg-vt-surface shadow-2xl animate-fade-in sm:w-96"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-vt-border">
        <h3 className="font-semibold">Notifications</h3>
      </div>
      <div className="max-h-96 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center py-12 gap-3 text-vt-muted">
            <Bell size={32} />
            <p className="text-sm">No notifications yet</p>
          </div>
        ) : (
          notifications.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => handleNotificationClick(n)}
              className={`flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-vt-chip transition-colors cursor-pointer ${
                !n.is_read ? 'bg-blue-500/5' : ''
              }`}
            >
              {n.sender_avatar ? (
                <img src={n.sender_avatar} className="w-10 h-10 rounded-full flex-shrink-0 object-cover" alt="" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-vt-chip flex-shrink-0 flex items-center justify-center">
                  <Bell size={16} />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm leading-snug">{n.message}</p>
                <p className="text-xs text-vt-muted mt-0.5">{formatTimeAgo(n.created_at)}</p>
              </div>
              {!n.is_read && <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-2" />}
            </button>
          ))
        )}
      </div>
    </div>
  )
}
