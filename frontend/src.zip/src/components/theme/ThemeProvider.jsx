import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { Toaster } from 'react-hot-toast'
import { createTheme, ThemeProvider as MuiThemeProvider } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'

const THEME_KEY = 'voiletube-theme'
const ThemeContext = createContext(null)
const FONT_STACK = 'Inter, -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", system-ui, sans-serif'

const colorSchemes = {
  light: {
    palette: {
      mode: 'light',
      primary: { main: '#0071e3', dark: '#005cd2', contrastText: '#ffffff' },
      background: { default: '#f4f5f7', paper: '#ffffff' },
      text: { primary: '#090c12', secondary: '#686f7c' },
      divider: '#d8dbe2',
    },
    vt: {
      '--vt-bg': '244 245 247',
      '--vt-surface': '255 255 255',
      '--vt-surface-strong': '251 251 252',
      '--vt-surface-soft': '237 239 243',
      '--vt-border': '216 219 226',
      '--vt-text': '9 12 18',
      '--vt-muted': '104 111 124',
      '--vt-accent': '0 113 227',
      '--vt-accent-hover': '0 92 210',
      '--vt-chip': '235 237 242',
      '--vt-chip-hover': '224 228 236',
      '--vt-gold': '203 164 82',
      '--vt-shadow': '17 23 34',
      '--vt-glow': '255 255 255',
      '--brand-cyan': '8 145 178',
      '--brand-violet': '109 40 217',
      '--brand-pink': '190 24 93',
      '--brand-amber': '180 83 9',
      '--brand-mint': '5 150 105',
      '--brand-shell': '255 255 255',
      '--brand-ring': '193 199 211',
    },
    appBackground:
      'radial-gradient(circle at 50% -20%, rgb(var(--vt-glow) / 0.18), transparent 38rem), linear-gradient(180deg, rgb(var(--vt-surface-soft) / 0.68), transparent 380px), linear-gradient(to bottom, rgb(var(--vt-bg)), rgb(var(--vt-bg)))',
    toastShadow: '0 18px 48px rgba(15, 23, 42, 0.12)',
  },
  dark: {
    palette: {
      mode: 'dark',
      primary: { main: '#419cff', dark: '#124a82', contrastText: '#ffffff' },
      background: { default: '#000000', paper: '#07080a' },
      text: { primary: '#fafafc', secondary: '#848c99' },
      divider: '#1c1f26',
    },
    vt: {
      '--vt-bg': '0 0 0',
      '--vt-surface': '7 8 10',
      '--vt-surface-strong': '12 13 16',
      '--vt-surface-soft': '3 4 6',
      '--vt-border': '28 31 38',
      '--vt-text': '250 250 252',
      '--vt-muted': '132 140 153',
      '--vt-accent': '65 156 255',
      '--vt-accent-hover': '112 184 255',
      '--vt-chip': '13 15 19',
      '--vt-chip-hover': '24 27 34',
      '--vt-gold': '224 184 95',
      '--vt-shadow': '0 0 0',
      '--vt-glow': '0 0 0',
      '--brand-cyan': '34 211 238',
      '--brand-violet': '139 92 246',
      '--brand-pink': '236 72 153',
      '--brand-amber': '245 158 11',
      '--brand-mint': '52 211 153',
      '--brand-shell': '12 13 16',
      '--brand-ring': '45 49 60',
    },
    appBackground:
      'radial-gradient(circle at 50% -22%, rgb(var(--vt-accent) / 0.08), transparent 32rem), linear-gradient(180deg, rgb(var(--vt-surface-soft) / 0.98), transparent 360px), linear-gradient(to bottom, rgb(var(--vt-bg)), rgb(var(--vt-bg)))',
    toastShadow: '0 18px 48px rgba(0, 0, 0, 0.35)',
  },
}

function getInitialTheme() {
  if (typeof window === 'undefined') return 'system'

  const storedTheme = window.localStorage.getItem(THEME_KEY)
  if (storedTheme === 'light' || storedTheme === 'dark' || storedTheme === 'system') {
    return storedTheme
  }

  return 'system'
}

function getSystemTheme() {
  if (typeof window === 'undefined') return 'dark'
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(getInitialTheme)
  const [resolvedTheme, setResolvedTheme] = useState(() => (
    theme === 'system' ? getSystemTheme() : theme
  ))

  const muiTheme = useMemo(() => createTheme({
    palette: colorSchemes[resolvedTheme].palette,
    shape: {
      borderRadius: 8,
    },
    typography: {
      fontFamily: FONT_STACK,
      button: {
        textTransform: 'none',
        fontWeight: 600,
      },
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          html: {
            minHeight: '100%',
            backgroundColor: colorSchemes[resolvedTheme].palette.background.default,
            color: colorSchemes[resolvedTheme].palette.text.primary,
          },
          body: {
            minHeight: '100%',
            backgroundColor: colorSchemes[resolvedTheme].palette.background.default,
            color: colorSchemes[resolvedTheme].palette.text.primary,
            fontFamily: FONT_STACK,
            scrollbarWidth: 'thin',
            scrollbarColor: `rgb(var(--vt-border)) transparent`,
          },
          '#root': {
            minHeight: '100%',
          },
          '::selection': {
            backgroundColor: 'rgb(var(--vt-accent) / 0.18)',
          },
          '::-webkit-scrollbar': {
            width: 6,
            height: 6,
          },
          '::-webkit-scrollbar-track': {
            background: 'transparent',
          },
          '::-webkit-scrollbar-thumb': {
            background: 'rgb(var(--vt-border))',
            borderRadius: 3,
          },
          '::-webkit-scrollbar-thumb:hover': {
            background: 'rgb(var(--vt-muted))',
          },
        },
      },
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            backgroundColor: 'rgb(var(--vt-surface-strong))',
            border: '1px solid rgb(var(--vt-border))',
            color: 'rgb(var(--vt-text))',
            boxShadow: '0 18px 48px rgb(var(--vt-shadow) / 0.16)',
            fontSize: 12,
          },
        },
      },
      MuiToggleButton: {
        styleOverrides: {
          root: {
            border: 0,
            borderRadius: 999,
            color: 'rgb(var(--vt-muted))',
            padding: '7px 10px',
            '&:hover': {
              backgroundColor: 'rgb(var(--vt-chip-hover) / 0.72)',
              color: 'rgb(var(--vt-text))',
            },
            '&.Mui-selected': {
              backgroundColor: 'rgb(var(--vt-text))',
              color: 'rgb(var(--vt-bg))',
              '&:hover': {
                backgroundColor: 'rgb(var(--vt-text) / 0.88)',
              },
            },
          },
        },
      },
      MuiToggleButtonGroup: {
        styleOverrides: {
          root: {
            gap: 2,
            border: '1px solid rgb(var(--vt-border) / 0.82)',
            borderRadius: 999,
            backgroundColor: 'rgb(var(--vt-surface) / 0.72)',
            boxShadow: 'inset 0 1px 0 rgb(var(--vt-glow) / 0.12)',
            padding: 3,
          },
        },
      },
    },
  }), [resolvedTheme])

  const value = useMemo(() => ({
    theme,
    resolvedTheme,
    setTheme,
    toggleTheme: () => setTheme((current) => {
      const currentResolvedTheme = current === 'system' ? getSystemTheme() : current
      return currentResolvedTheme === 'dark' ? 'light' : 'dark'
    }),
  }), [theme, resolvedTheme])

  useEffect(() => {
    if (typeof document === 'undefined') return

    const root = document.documentElement
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')

    const applyTheme = () => {
      const nextResolvedTheme = theme === 'system'
        ? (mediaQuery.matches ? 'dark' : 'light')
        : theme

      root.classList.remove('light', 'dark')
      root.classList.add(nextResolvedTheme)
      root.dataset.theme = nextResolvedTheme
      root.style.colorScheme = nextResolvedTheme
      root.style.setProperty('--vt-app-bg-image', colorSchemes[nextResolvedTheme].appBackground)
      Object.entries(colorSchemes[nextResolvedTheme].vt).forEach(([key, value]) => {
        root.style.setProperty(key, value)
      })
      document.body.dataset.theme = nextResolvedTheme
      setResolvedTheme(nextResolvedTheme)
    }

    applyTheme()
    window.localStorage.setItem(THEME_KEY, theme)

    if (theme !== 'system') return undefined

    mediaQuery.addEventListener('change', applyTheme)
    return () => mediaQuery.removeEventListener('change', applyTheme)
  }, [theme])

  return (
    <ThemeContext.Provider value={value}>
      <MuiThemeProvider theme={muiTheme}>
        <CssBaseline enableColorScheme />
        {children}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}

export function ThemedToaster() {
  const { resolvedTheme } = useTheme()

  return (
    <Toaster
      position="bottom-left"
      toastOptions={{
        style: {
          background: 'rgb(var(--vt-surface))',
          color: 'rgb(var(--vt-text))',
          border: '1px solid rgb(var(--vt-border))',
          boxShadow: colorSchemes[resolvedTheme].toastShadow,
        },
      }}
    />
  )
}
