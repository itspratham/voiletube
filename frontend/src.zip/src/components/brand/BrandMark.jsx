export default function BrandMark({ className = 'h-9 w-9' }) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id="voiletube-screen" x1="8" x2="56" y1="12" y2="52">
          <stop offset="0%" stopColor="rgb(var(--brand-cyan))" />
          <stop offset="46%" stopColor="rgb(var(--brand-violet))" />
          <stop offset="76%" stopColor="rgb(var(--brand-pink))" />
          <stop offset="100%" stopColor="rgb(var(--brand-amber))" />
        </linearGradient>
        <linearGradient id="voiletube-timeline" x1="12" x2="52" y1="48" y2="48">
          <stop offset="0%" stopColor="rgb(var(--brand-mint))" />
          <stop offset="52%" stopColor="rgb(var(--brand-cyan))" />
          <stop offset="100%" stopColor="rgb(var(--brand-pink))" />
        </linearGradient>
        <linearGradient id="voiletube-play" x1="25" x2="43" y1="20" y2="43">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="rgb(var(--brand-shell))" />
        </linearGradient>
        <filter id="voiletube-glow" x="-35%" y="-35%" width="170%" height="170%">
          <feGaussianBlur stdDeviation="2.2" result="blur" />
          <feColorMatrix
            in="blur"
            type="matrix"
            values="0 0 0 0 0.25 0 0 0 0 0.38 0 0 0 0 1 0 0 0 0.45 0"
          />
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <path
        d="M8.5 21.5C8.5 15.7 13.2 11 19 11h26c5.8 0 10.5 4.7 10.5 10.5v21C55.5 48.3 50.8 53 45 53H19C13.2 53 8.5 48.3 8.5 42.5Z"
        fill="rgb(var(--brand-shell))"
        stroke="rgb(var(--brand-ring))"
        strokeWidth="1.6"
      />
      <path
        d="M13.5 22.2c0-3.1 2.5-5.7 5.6-5.7h25.8c3.1 0 5.6 2.6 5.6 5.7v17.6c0 3.1-2.5 5.7-5.6 5.7H19.1c-3.1 0-5.6-2.6-5.6-5.7Z"
        fill="url(#voiletube-screen)"
        filter="url(#voiletube-glow)"
      />
      <path
        d="M18 38c8.4-7.1 20.7-11.2 31.6-10.4"
        fill="none"
        stroke="rgb(var(--brand-shell))"
        strokeLinecap="round"
        strokeWidth="3"
        opacity="0.22"
      />
      <path
        d="M27.5 24.2 41.2 32 27.5 39.8Z"
        fill="url(#voiletube-play)"
        opacity="0.96"
      />
      <path
        d="M18 48h28"
        stroke="url(#voiletube-timeline)"
        strokeLinecap="round"
        strokeWidth="3.4"
      />
      <path
        d="M18 48h11"
        stroke="rgb(var(--brand-shell))"
        strokeLinecap="round"
        strokeWidth="3.4"
        opacity="0.92"
      />
      <circle cx="31" cy="48" r="3.7" fill="rgb(var(--brand-pink))" stroke="rgb(var(--brand-shell))" strokeWidth="1.4" />
      <path
        d="M22 9.2 24.7 6.5M42 9.2l-2.7-2.7"
        fill="none"
        stroke="url(#voiletube-timeline)"
        strokeLinecap="round"
        strokeWidth="2.4"
      />
    </svg>
  )
}
